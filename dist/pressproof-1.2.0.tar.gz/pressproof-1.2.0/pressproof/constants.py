
class Constants:
    COLOR_ORANGE = "\033[38;2;255;111;60m"

